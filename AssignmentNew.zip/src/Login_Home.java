



public class Login_Home {

    
    public  void main() {
        Login_Main newLogin = new Login_Main();
        String a = newLogin.main();
        switch (a) {
            case "1":
                System.out.print("this is 1");
                break;
            case "2":
                System.out.print("this is 2");
                break;
            case "3":
                System.out.print("this is 3");
                break;

        }
    }
}
